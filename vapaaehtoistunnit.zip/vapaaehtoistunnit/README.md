# Vapaaehtoistunnit

Mobiilikäyttöön suunniteltu Django-sovellus vapaaehtoistyötuntien seurantaan.
Näkymät (alapalkin painikkeet): **Koti · Historia · Kirjaa (+) · Tilastot · Järjestöt**.

## Käynnistys (kehitys)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DJANGO_DEBUG=1
python manage.py migrate
python manage.py createsuperuser   # valinnainen, admin: /hallinta/
python manage.py runserver
```

Avaa puhelimella `http://<koneen-ip>:8000` (lisää IP `DJANGO_ALLOWED_HOSTS`-muuttujaan).

## Testit

```bash
python manage.py test
```

## Tailwind

Käännetty `tunnit/static/tunnit/css/app.css` on mukana, joten Nodea ei tarvita ajoon.
Tyylejä muuttaessa:

```bash
npm install
npm run css:watch      # tai: npm run css:build
```

## Tuotanto

1. Kopioi `.env.example` ja aseta arvot (erityisesti `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS`).
2. `python manage.py migrate && python manage.py collectstatic --noinput`
3. Aja esim. `gunicorn config.wsgi` HTTPS-välityspalvelimen (nginx/Caddy/Traefik) takana,
   ja aseta `DJANGO_BEHIND_PROXY=1` vain jos välityspalvelin asettaa `X-Forwarded-Proto`-otsakkeen.
4. Tarkista: `python manage.py check --deploy`.
5. PostgreSQL: asenna `psycopg[binary]` ja aseta `POSTGRES_*`-muuttujat.

## Turvallisuusratkaisut

- Salaisuudet vain ympäristömuuttujista; sovellus ei käynnisty tuotannossa ilman `DJANGO_SECRET_KEY`:tä.
- Kaikki kyselyt rajataan `owner=request.user`; vieraan datan URL:t palauttavat 404 (IDOR-esto).
  Lomakkeiden järjestövalinta rajataan käyttäjän omiin järjestöihin.
- CSRF kaikissa POST-lomakkeissa, poisto/uloskirjautuminen vain POST-metodilla.
- Tiukka CSP (`script-src 'self'; style-src 'self'`), ei inline-koodia; X-Frame-Options DENY,
  Permissions-Policy, `no-store` kirjautuneille sivuille.
- Evästeet HttpOnly + SameSite=Lax, tuotannossa Secure + HSTS + SSL-uudelleenohjaus.
- Salasanavaatimus min. 10 merkkiä + Djangon validaattorit; kirjautumisyritysten rajoitus (5 / 5 min).
- Syötteiden validointi (tunnit 0,25–24, ei tulevia päiviä, pituusrajat), DB-tason CHECK/UNIQUE-rajoitteet.
- CSV-viennissä suojaus kaavainjektiota vastaan (`=`, `+`, `-`, `@`).
- Admin-polku vaihdettavissa (`DJANGO_ADMIN_URL`). Rekisteröinnin voi sulkea (`REGISTRATION_OPEN=0`).

Huom: kirjautumisrajoitus käyttää Djangon välimuistia (oletuksena prosessikohtainen). Usean
prosessin tuotannossa määritä jaettu välimuisti (Redis/Memcached/DatabaseCache).
