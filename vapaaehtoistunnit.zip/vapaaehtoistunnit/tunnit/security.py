"""Kirjautumisyritysten rajoitus (brute force -suoja) välimuistin avulla."""

from django.conf import settings
from django.contrib.auth.views import LoginView
from django.core.cache import cache


class ThrottledLoginView(LoginView):
    """Lukitsee käyttäjätunnus+IP-parin hetkeksi liian monen epäonnistuneen yrityksen jälkeen.

    Huom: oletus-LocMemCache on prosessikohtainen. Tuotannossa käytä jaettua
    välimuistia (Redis/Memcached/tietokanta) ja varmista, että REMOTE_ADDR on oikea
    (esim. välityspalvelimen takana).
    """

    redirect_authenticated_user = True
    template_name = "registration/login.html"

    def _key(self, request) -> str:
        username = (request.POST.get("username") or "").strip().lower()[:150]
        return f"login-fail:{request.META.get('REMOTE_ADDR', '')}:{username}"

    def post(self, request, *args, **kwargs):
        if cache.get(self._key(request), 0) >= settings.LOGIN_MAX_ATTEMPTS:
            form = self.get_form()
            form.add_error(None, "Liian monta epäonnistunutta yritystä. Yritä hetken kuluttua uudelleen.")
            response = self.render_to_response(self.get_context_data(form=form))
            response.status_code = 429
            return response
        return super().post(request, *args, **kwargs)

    def form_invalid(self, form):
        key = self._key(self.request)
        cache.add(key, 0, settings.LOGIN_LOCKOUT_SECONDS)
        try:
            cache.incr(key)
        except ValueError:
            cache.set(key, 1, settings.LOGIN_LOCKOUT_SECONDS)
        return super().form_invalid(form)

    def form_valid(self, form):
        cache.delete(self._key(self.request))
        return super().form_valid(form)
