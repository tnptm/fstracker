from decimal import Decimal, InvalidOperation

from django import template

register = template.Library()


@register.filter
def tunnit(value) -> str:
    """2.50 -> '2,5 h', 10.00 -> '10 h'."""
    try:
        d = Decimal(value or 0).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError, ValueError):
        return "–"
    text = format(d, "f").rstrip("0").rstrip(".")
    return f"{text.replace('.', ',')} h"
