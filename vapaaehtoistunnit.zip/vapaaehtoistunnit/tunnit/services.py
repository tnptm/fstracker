"""Tilastolaskenta. Kaikki funktiot rajaavat kyselyn käyttäjän omiin tietoihin."""

from decimal import Decimal

from django.db.models import DecimalField, Sum, Value
from django.db.models.functions import Coalesce, ExtractMonth

from .models import VolunteerEntry

ZERO = Decimal("0")
MONTH_LABELS = ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"]
_SUM = Coalesce(
    Sum("hours"), Value(ZERO), output_field=DecimalField(max_digits=10, decimal_places=2)
)


def sum_hours(queryset) -> Decimal:
    return queryset.aggregate(total=_SUM)["total"]


def percent(part: Decimal, whole: Decimal) -> int:
    """Osuus kokonaislukuna 0–100. Nolla, jos jakaja on nolla."""
    if not whole or whole <= 0:
        return 0
    return int(min(Decimal(100), (Decimal(part) * 100 / Decimal(whole)).quantize(Decimal("1"))))


def year_total(user, year: int) -> Decimal:
    return sum_hours(VolunteerEntry.objects.filter(owner=user, date__year=year))


def month_total(user, year: int, month: int) -> Decimal:
    return sum_hours(
        VolunteerEntry.objects.filter(owner=user, date__year=year, date__month=month)
    )


def monthly_breakdown(user, year: int) -> list[dict]:
    rows = (
        VolunteerEntry.objects.filter(owner=user, date__year=year)
        .annotate(m=ExtractMonth("date"))
        .values("m")
        .annotate(total=Sum("hours"))
        .order_by("m")
    )
    totals = {row["m"]: row["total"] for row in rows}
    peak = max(totals.values(), default=ZERO)
    return [
        {
            "label": MONTH_LABELS[i - 1],
            "hours": totals.get(i, ZERO),
            "pct": percent(totals.get(i, ZERO), peak),
        }
        for i in range(1, 13)
    ]


def organization_breakdown(user, year: int) -> list[dict]:
    rows = list(
        VolunteerEntry.objects.filter(owner=user, date__year=year)
        .values("organization__name")
        .annotate(total=Sum("hours"))
        .order_by("-total", "organization__name")
    )
    peak = rows[0]["total"] if rows else ZERO
    return [
        {"name": r["organization__name"], "hours": r["total"], "pct": percent(r["total"], peak)}
        for r in rows
    ]
