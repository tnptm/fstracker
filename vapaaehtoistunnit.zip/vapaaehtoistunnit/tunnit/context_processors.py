from django.conf import settings

SECTIONS = {
    "dashboard": "dashboard",
    "entry_create": "entry_create",
    "entry_list": "entry_list",
    "entry_edit": "entry_list",
    "stats": "stats",
    "goal_set": "stats",
    "organizations": "organizations",
}


def nav(request):
    match = getattr(request, "resolver_match", None)
    return {
        "nav_section": SECTIONS.get(match.url_name) if match else None,
        "registration_open": settings.REGISTRATION_OPEN,
    }
