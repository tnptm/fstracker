from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views
from .security import ThrottledLoginView

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("kirjaa/", views.entry_create, name="entry_create"),
    path("historia/", views.entry_list, name="entry_list"),
    path("historia/<int:pk>/muokkaa/", views.entry_edit, name="entry_edit"),
    path("historia/<int:pk>/poista/", views.entry_delete, name="entry_delete"),
    path("tilastot/", views.stats, name="stats"),
    path("tilastot/tavoite/", views.goal_set, name="goal_set"),
    path("tilastot/vie.csv", views.export_csv, name="export_csv"),
    path("jarjestot/", views.organizations, name="organizations"),
    path("jarjestot/<int:pk>/poista/", views.organization_delete, name="organization_delete"),
    path("kirjaudu/", ThrottledLoginView.as_view(), name="login"),
    path("kirjaudu-ulos/", LogoutView.as_view(), name="logout"),
    path("rekisteroidy/", views.register, name="register"),
]
