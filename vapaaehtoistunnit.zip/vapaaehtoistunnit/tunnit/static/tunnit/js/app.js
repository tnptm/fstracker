// Kevyt apuskripti. Ei inline-koodia, jotta tiukka Content-Security-Policy toimii.
(() => {
  "use strict";

  // Palkit ja edistymisjanat: leveys/korkeus data-attribuutista (CSP estää inline-style-attribuutit).
  const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));
  requestAnimationFrame(() => {
    document.querySelectorAll("[data-width]").forEach((el) => {
      el.style.width = `${clamp(el.dataset.width)}%`;
    });
    document.querySelectorAll("[data-height]").forEach((el) => {
      el.style.height = `${clamp(el.dataset.height)}%`;
    });
  });

  // Vahvistus ennen poistoa.
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  // Estä tuplalähetys.
  document.querySelectorAll("form[data-once]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (form.dataset.submitted === "1") {
        event.preventDefault();
        return;
      }
      form.dataset.submitted = "1";
      form.querySelectorAll("button[type=submit]").forEach((b) => b.classList.add("opacity-60"));
    });
  });

  // Tuntien pikavalinnat.
  const hoursInput = document.getElementById("id_hours");
  document.querySelectorAll("[data-set-hours]").forEach((button) => {
    button.addEventListener("click", () => {
      if (!hoursInput) return;
      hoursInput.value = button.dataset.setHours;
      hoursInput.dispatchEvent(new Event("input", { bubbles: true }));
    });
  });

  // Ilmoitukset katoavat itsestään.
  document.querySelectorAll("[data-toast]").forEach((toast) => {
    setTimeout(() => toast.remove(), 5000);
  });
})();
