from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models.functions import Lower

MIN_HOURS = Decimal("0.25")
MAX_HOURS = Decimal("24")


class Organization(models.Model):
    """Järjestö tai yhteisö, jolle vapaaehtoistyötä tehdään. Kuuluu aina yhdelle käyttäjälle."""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="organizations"
    )
    name = models.CharField("nimi", max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = [Lower("name")]
        constraints = [
            models.UniqueConstraint(Lower("name"), "owner", name="uniq_org_name_per_owner"),
        ]
        verbose_name = "järjestö"
        verbose_name_plural = "järjestöt"

    def __str__(self) -> str:
        return self.name


class VolunteerEntry(models.Model):
    """Yksittäinen tuntikirjaus."""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="entries"
    )
    # PROTECT: järjestön poisto ei saa hiljaa hävittää kirjauksia.
    organization = models.ForeignKey(
        Organization, on_delete=models.PROTECT, related_name="entries", verbose_name="järjestö"
    )
    date = models.DateField("päivä")
    hours = models.DecimalField(
        "tunnit",
        max_digits=4,
        decimal_places=2,
        validators=[MinValueValidator(MIN_HOURS), MaxValueValidator(MAX_HOURS)],
    )
    description = models.CharField("kuvaus", max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date", "-created_at"]
        indexes = [models.Index(fields=["owner", "date"], name="entry_owner_date_idx")]
        constraints = [
            models.CheckConstraint(condition=models.Q(hours__gt=0), name="entry_hours_positive"),
        ]
        verbose_name = "tuntikirjaus"
        verbose_name_plural = "tuntikirjaukset"

    def __str__(self) -> str:
        return f"{self.date} {self.organization} {self.hours} h"


class YearlyGoal(models.Model):
    """Käyttäjän vuosittainen tuntitavoite."""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="goals"
    )
    year = models.PositiveSmallIntegerField("vuosi")
    target_hours = models.PositiveIntegerField(
        "tavoite (h)", validators=[MinValueValidator(1), MaxValueValidator(10000)]
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["owner", "year"], name="uniq_goal_per_year"),
        ]

    def __str__(self) -> str:
        return f"{self.year}: {self.target_hours} h"
