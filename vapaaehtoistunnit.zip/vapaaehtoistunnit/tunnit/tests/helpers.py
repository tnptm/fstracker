from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase

from tunnit.models import Organization, VolunteerEntry

User = get_user_model()
PASSWORD = "testi-salasana-123"


class BaseTestCase(TestCase):
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user("anna", password=PASSWORD)
        self.other = User.objects.create_user("bertta", password=PASSWORD)
        self.org = Organization.objects.create(owner=self.user, name="Punainen Risti")
        self.other_org = Organization.objects.create(owner=self.other, name="Kummi")

    def login(self, username="anna"):
        self.assertTrue(self.client.login(username=username, password=PASSWORD))

    def entry(self, owner=None, org=None, d=None, hours="2", description=""):
        owner = owner or self.user
        org = org or (self.org if owner == self.user else self.other_org)
        return VolunteerEntry.objects.create(
            owner=owner, organization=org, date=d or date.today(),
            hours=Decimal(hours), description=description,
        )
