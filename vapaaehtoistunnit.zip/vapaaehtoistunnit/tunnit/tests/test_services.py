from datetime import date
from decimal import Decimal

from tunnit import services

from .helpers import BaseTestCase


class ServiceTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.entry(d=date(2026, 1, 10), hours="2")
        self.entry(d=date(2026, 1, 20), hours="3.5")
        self.entry(d=date(2026, 3, 1), hours="1")
        self.entry(d=date(2025, 12, 31), hours="9")
        self.entry(owner=self.other, d=date(2026, 1, 10), hours="20")

    def test_year_total_only_counts_own_entries(self):
        self.assertEqual(services.year_total(self.user, 2026), Decimal("6.5"))
        self.assertEqual(services.year_total(self.user, 2025), Decimal("9"))
        self.assertEqual(services.year_total(self.user, 2020), Decimal("0"))

    def test_month_total(self):
        self.assertEqual(services.month_total(self.user, 2026, 1), Decimal("5.5"))

    def test_monthly_breakdown(self):
        months = services.monthly_breakdown(self.user, 2026)
        self.assertEqual(len(months), 12)
        self.assertEqual(months[0]["hours"], Decimal("5.5"))
        self.assertEqual(months[0]["pct"], 100)
        self.assertEqual(months[2]["pct"], 18)
        self.assertEqual(months[1]["hours"], Decimal("0"))

    def test_organization_breakdown(self):
        rows = services.organization_breakdown(self.user, 2026)
        self.assertEqual(rows, [{"name": "Punainen Risti", "hours": Decimal("6.5"), "pct": 100}])

    def test_percent_edge_cases(self):
        self.assertEqual(services.percent(Decimal("5"), Decimal("0")), 0)
        self.assertEqual(services.percent(Decimal("250"), Decimal("100")), 100)
