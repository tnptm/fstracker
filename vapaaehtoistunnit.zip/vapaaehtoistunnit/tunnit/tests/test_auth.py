from django.test import override_settings
from django.urls import reverse

from .helpers import PASSWORD, BaseTestCase, User


class RegistrationTests(BaseTestCase):
    def test_register_logs_in_and_redirects(self):
        response = self.client.post(reverse("register"), {
            "username": "uusi", "password1": "Pitka-Salasana-42", "password2": "Pitka-Salasana-42",
        })
        self.assertRedirects(response, reverse("organizations"))
        self.assertTrue(User.objects.filter(username="uusi").exists())
        self.assertIn("_auth_user_id", self.client.session)

    def test_weak_password_rejected(self):
        response = self.client.post(reverse("register"), {
            "username": "uusi", "password1": "12345678", "password2": "12345678",
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username="uusi").exists())

    def test_short_password_rejected(self):
        response = self.client.post(reverse("register"), {
            "username": "uusi", "password1": "Lyhyt1!x", "password2": "Lyhyt1!x",
        })
        self.assertFalse(User.objects.filter(username="uusi").exists())

    @override_settings(REGISTRATION_OPEN=False)
    def test_registration_can_be_closed(self):
        self.assertEqual(self.client.get(reverse("register")).status_code, 404)


class LoginTests(BaseTestCase):
    def test_login_and_logout(self):
        response = self.client.post(reverse("login"), {"username": "anna", "password": PASSWORD})
        self.assertRedirects(response, reverse("dashboard"))
        self.assertEqual(self.client.get(reverse("logout")).status_code, 405)  # vain POST
        self.client.post(reverse("logout"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_login_ignores_external_next_url(self):
        response = self.client.post(
            reverse("login") + "?next=https://evil.example/",
            {"username": "anna", "password": PASSWORD},
        )
        self.assertRedirects(response, reverse("dashboard"))

    def test_brute_force_lockout(self):
        for _ in range(5):
            self.client.post(reverse("login"), {"username": "anna", "password": "väärin"})
        response = self.client.post(reverse("login"), {"username": "anna", "password": PASSWORD})
        self.assertEqual(response.status_code, 429)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_lockout_is_per_username(self):
        for _ in range(5):
            self.client.post(reverse("login"), {"username": "anna", "password": "väärin"})
        response = self.client.post(reverse("login"), {"username": "bertta", "password": PASSWORD})
        self.assertEqual(response.status_code, 302)

    def test_successful_login_resets_counter(self):
        for _ in range(3):
            self.client.post(reverse("login"), {"username": "anna", "password": "väärin"})
        self.client.post(reverse("login"), {"username": "anna", "password": PASSWORD})
        self.client.post(reverse("logout"))
        for _ in range(4):
            self.client.post(reverse("login"), {"username": "anna", "password": "väärin"})
        response = self.client.post(reverse("login"), {"username": "anna", "password": PASSWORD})
        self.assertEqual(response.status_code, 302)
