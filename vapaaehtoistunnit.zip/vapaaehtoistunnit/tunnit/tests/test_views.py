from datetime import date, timedelta
from decimal import Decimal

from django.urls import reverse
from django.utils import timezone

from tunnit.models import Organization, VolunteerEntry, YearlyGoal

from .helpers import BaseTestCase


class AuthRequiredTests(BaseTestCase):
    def test_all_protected_pages_redirect_anonymous_users(self):
        entry = self.entry()
        urls = [
            reverse("dashboard"), reverse("entry_create"), reverse("entry_list"),
            reverse("entry_edit", args=[entry.pk]), reverse("stats"),
            reverse("export_csv"), reverse("organizations"),
        ]
        for url in urls:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 302)
                self.assertTrue(response["Location"].startswith(reverse("login")))

    def test_post_endpoints_redirect_anonymous_and_change_nothing(self):
        entry = self.entry()
        self.client.post(reverse("entry_delete", args=[entry.pk]))
        self.client.post(reverse("organization_delete", args=[self.org.pk]))
        self.client.post(reverse("goal_set"), {"year": 2026, "target_hours": 50})
        self.assertTrue(VolunteerEntry.objects.filter(pk=entry.pk).exists())
        self.assertEqual(YearlyGoal.objects.count(), 0)


class DashboardTests(BaseTestCase):
    def test_dashboard_shows_totals_and_nav(self):
        today = timezone.localdate()
        self.entry(d=today, hours="2.5")
        self.entry(owner=self.other, hours="99")
        YearlyGoal.objects.create(owner=self.user, year=today.year, target_hours=10)
        self.login()
        response = self.client.get(reverse("dashboard"))
        self.assertContains(response, "2,5 h")
        self.assertNotContains(response, "99 h")
        self.assertEqual(response.context["goal_pct"], 25)
        for name in ["dashboard", "entry_list", "entry_create", "stats", "organizations"]:
            self.assertContains(response, f'href="{reverse(name)}"')

    def test_security_headers(self):
        self.login()
        response = self.client.get(reverse("dashboard"))
        self.assertIn("script-src 'self'", response["Content-Security-Policy"])
        self.assertNotIn("unsafe-inline", response["Content-Security-Policy"])
        self.assertIn("no-store", response["Cache-Control"])
        self.assertEqual(response["X-Frame-Options"], "DENY")


class EntryViewTests(BaseTestCase):
    def post_data(self, **kw):
        data = {"organization": self.org.pk, "date": timezone.localdate().isoformat(),
                "hours": "3", "description": "Talkoot"}
        data.update(kw)
        return data

    def test_create_entry(self):
        self.login()
        response = self.client.post(reverse("entry_create"), self.post_data())
        self.assertRedirects(response, reverse("dashboard"))
        entry = VolunteerEntry.objects.get()
        self.assertEqual((entry.owner, entry.hours), (self.user, Decimal("3")))

    def test_create_requires_organization_first(self):
        Organization.objects.filter(owner=self.user).delete()
        self.login()
        self.assertRedirects(self.client.get(reverse("entry_create")), reverse("organizations"))

    def test_cannot_create_entry_for_foreign_organization(self):
        self.login()
        response = self.client.post(reverse("entry_create"), self.post_data(organization=self.other_org.pk))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(VolunteerEntry.objects.count(), 0)

    def test_edit_entry(self):
        entry = self.entry(hours="1")
        self.login()
        response = self.client.post(reverse("entry_edit", args=[entry.pk]), self.post_data(hours="4"))
        self.assertRedirects(response, reverse("entry_list"))
        entry.refresh_from_db()
        self.assertEqual(entry.hours, Decimal("4"))

    def test_cannot_view_edit_or_delete_foreign_entry(self):
        foreign = self.entry(owner=self.other)
        self.login()
        self.assertEqual(self.client.get(reverse("entry_edit", args=[foreign.pk])).status_code, 404)
        self.assertEqual(
            self.client.post(reverse("entry_edit", args=[foreign.pk]), self.post_data(hours="9")).status_code, 404
        )
        self.assertEqual(self.client.post(reverse("entry_delete", args=[foreign.pk])).status_code, 404)
        foreign.refresh_from_db()
        self.assertEqual(foreign.hours, Decimal("2"))

    def test_delete_requires_post(self):
        entry = self.entry()
        self.login()
        self.assertEqual(self.client.get(reverse("entry_delete", args=[entry.pk])).status_code, 405)
        self.client.post(reverse("entry_delete", args=[entry.pk]))
        self.assertFalse(VolunteerEntry.objects.filter(pk=entry.pk).exists())

    def test_csrf_is_enforced(self):
        from django.test import Client

        client = Client(enforce_csrf_checks=True)
        client.login(username="anna", password="testi-salasana-123")
        entry = self.entry()
        response = client.post(reverse("entry_delete", args=[entry.pk]))
        self.assertEqual(response.status_code, 403)
        self.assertTrue(VolunteerEntry.objects.filter(pk=entry.pk).exists())


class EntryListTests(BaseTestCase):
    def test_only_own_entries_and_filters(self):
        self.entry(d=date(2026, 1, 5), hours="1", description="tammi")
        self.entry(d=date(2026, 2, 5), hours="2", description="helmi")
        self.entry(owner=self.other, d=date(2026, 1, 5), description="salainen")
        self.login()
        response = self.client.get(reverse("entry_list"))
        self.assertContains(response, "tammi")
        self.assertNotContains(response, "salainen")
        response = self.client.get(reverse("entry_list"), {"kuukausi": "2026-02"})
        self.assertContains(response, "helmi")
        self.assertNotContains(response, "tammi")

    def test_foreign_org_filter_is_ignored_safely(self):
        self.entry(description="oma")
        self.login()
        response = self.client.get(reverse("entry_list"), {"jarjesto": self.other_org.pk})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context["filtered"])

    def test_garbage_params_do_not_crash(self):
        self.login()
        for params in [{"kuukausi": "xx"}, {"jarjesto": "abc"}, {"sivu": "-5"}, {"sivu": "zzz"}]:
            with self.subTest(params=params):
                self.assertEqual(self.client.get(reverse("entry_list"), params).status_code, 200)

    def test_pagination(self):
        for i in range(25):
            self.entry(d=date(2026, 1, 1) + timedelta(days=i % 20))
        self.login()
        response = self.client.get(reverse("entry_list"))
        self.assertEqual(len(response.context["page"]), 20)
        self.assertEqual(len(self.client.get(reverse("entry_list"), {"sivu": 2}).context["page"]), 5)

    def test_xss_is_escaped(self):
        self.entry(description="<script>alert(1)</script>")
        self.login()
        response = self.client.get(reverse("entry_list"))
        self.assertNotContains(response, "<script>alert(1)</script>")
        self.assertContains(response, "&lt;script&gt;")


class StatsAndGoalTests(BaseTestCase):
    def test_stats_page_and_invalid_year(self):
        self.entry(d=date(2026, 1, 5), hours="4")
        self.login()
        self.assertContains(self.client.get(reverse("stats"), {"vuosi": 2026}), "4 h")
        self.assertEqual(self.client.get(reverse("stats"), {"vuosi": "9999"}).status_code, 200)
        self.assertEqual(self.client.get(reverse("stats"), {"vuosi": "abc"}).status_code, 200)

    def test_set_and_update_goal(self):
        self.login()
        self.client.post(reverse("goal_set"), {"year": 2026, "target_hours": 50})
        self.client.post(reverse("goal_set"), {"year": 2026, "target_hours": 80})
        goal = YearlyGoal.objects.get(owner=self.user, year=2026)
        self.assertEqual(goal.target_hours, 80)

    def test_invalid_goal_rejected(self):
        self.login()
        self.client.post(reverse("goal_set"), {"year": 2026, "target_hours": -3})
        self.assertEqual(YearlyGoal.objects.count(), 0)

    def test_goal_is_per_user(self):
        YearlyGoal.objects.create(owner=self.other, year=2026, target_hours=500)
        self.login()
        self.assertIsNone(self.client.get(reverse("stats"), {"vuosi": 2026}).context["goal"])


class CsvExportTests(BaseTestCase):
    def test_export_contains_only_own_rows(self):
        self.entry(d=date(2026, 1, 5), hours="2.5", description="oma")
        self.entry(owner=self.other, description="vieras")
        self.login()
        response = self.client.get(reverse("export_csv"))
        body = response.content.decode("utf-8-sig")
        self.assertIn("2026-01-05;Punainen Risti;2,50;oma", body)
        self.assertNotIn("vieras", body)
        self.assertIn("attachment", response["Content-Disposition"])

    def test_csv_formula_injection_is_neutralised(self):
        self.entry(description='=HYPERLINK("http://evil.example","x")')
        Organization.objects.filter(pk=self.org.pk).update(name="@SUM(1+1)")
        self.login()
        body = self.client.get(reverse("export_csv")).content.decode("utf-8-sig")
        self.assertIn("'=HYPERLINK", body)
        self.assertIn("'@SUM", body)
        self.assertNotIn(";=HYPERLINK", body)

    def test_year_filter(self):
        self.entry(d=date(2025, 5, 5), description="vanha")
        self.entry(d=date(2026, 5, 5), description="uusi")
        self.login()
        body = self.client.get(reverse("export_csv"), {"vuosi": 2026}).content.decode("utf-8-sig")
        self.assertIn("uusi", body)
        self.assertNotIn("vanha", body)


class OrganizationViewTests(BaseTestCase):
    def test_create_and_duplicate(self):
        self.login()
        self.client.post(reverse("organizations"), {"name": "Uusi"})
        self.assertTrue(Organization.objects.filter(owner=self.user, name="Uusi").exists())
        self.client.post(reverse("organizations"), {"name": "uusi"})
        self.assertEqual(Organization.objects.filter(owner=self.user, name__iexact="uusi").count(), 1)

    def test_delete_empty_org(self):
        empty = Organization.objects.create(owner=self.user, name="Tyhjä")
        self.login()
        self.client.post(reverse("organization_delete", args=[empty.pk]))
        self.assertFalse(Organization.objects.filter(pk=empty.pk).exists())

    def test_delete_org_with_entries_is_blocked(self):
        self.entry()
        self.login()
        response = self.client.post(reverse("organization_delete", args=[self.org.pk]), follow=True)
        self.assertTrue(Organization.objects.filter(pk=self.org.pk).exists())
        self.assertContains(response, "kirjauksia")

    def test_cannot_delete_foreign_org(self):
        self.login()
        response = self.client.post(reverse("organization_delete", args=[self.other_org.pk]))
        self.assertEqual(response.status_code, 404)
        self.assertTrue(Organization.objects.filter(pk=self.other_org.pk).exists())
