from datetime import timedelta
from decimal import Decimal

from django.db import IntegrityError, transaction
from django.db.models import ProtectedError
from django.template import Context, Template
from django.utils import timezone

from tunnit.forms import EntryForm, GoalForm, OrganizationForm
from tunnit.models import Organization, VolunteerEntry

from .helpers import BaseTestCase


class ModelTests(BaseTestCase):
    def test_org_name_unique_per_owner_case_insensitive(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            Organization.objects.create(owner=self.user, name="punainen risti")

    def test_same_org_name_allowed_for_different_users(self):
        Organization.objects.create(owner=self.other, name="Punainen Risti")

    def test_db_rejects_non_positive_hours(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            self.entry(hours="0")

    def test_org_with_entries_is_protected(self):
        self.entry()
        with self.assertRaises(ProtectedError):
            self.org.delete()


class EntryFormTests(BaseTestCase):
    def data(self, **overrides):
        data = {
            "organization": self.org.pk,
            "date": timezone.localdate().isoformat(),
            "hours": "2.5",
            "description": "  Ruokajako ",
        }
        data.update(overrides)
        return data

    def test_valid_form_sets_owner_and_strips_description(self):
        form = EntryForm(self.data(), user=self.user)
        self.assertTrue(form.is_valid(), form.errors)
        entry = form.save()
        self.assertEqual(entry.owner, self.user)
        self.assertEqual(entry.description, "Ruokajako")

    def test_cannot_use_other_users_organization(self):
        form = EntryForm(self.data(organization=self.other_org.pk), user=self.user)
        self.assertFalse(form.is_valid())
        self.assertIn("organization", form.errors)

    def test_future_date_rejected(self):
        tomorrow = timezone.localdate() + timedelta(days=1)
        form = EntryForm(self.data(date=tomorrow.isoformat()), user=self.user)
        self.assertFalse(form.is_valid())
        self.assertIn("date", form.errors)

    def test_hours_bounds(self):
        for bad in ["0", "0.1", "-1", "24.5", "abc", ""]:
            with self.subTest(hours=bad):
                self.assertFalse(EntryForm(self.data(hours=bad), user=self.user).is_valid())
        for good in ["0.25", "24"]:
            with self.subTest(hours=good):
                self.assertTrue(EntryForm(self.data(hours=good), user=self.user).is_valid())

    def test_description_max_length(self):
        form = EntryForm(self.data(description="x" * 256), user=self.user)
        self.assertFalse(form.is_valid())

    def test_initial_date_is_today(self):
        form = EntryForm(user=self.user)
        self.assertEqual(form.initial["date"], timezone.localdate())


class OrganizationFormTests(BaseTestCase):
    def test_duplicate_name_rejected_case_insensitively(self):
        form = OrganizationForm({"name": "  punainen   risti "}, user=self.user)
        self.assertFalse(form.is_valid())

    def test_name_whitespace_normalised(self):
        form = OrganizationForm({"name": "  Uusi   yhdistys "}, user=self.user)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.save().name, "Uusi yhdistys")


class GoalFormTests(BaseTestCase):
    def test_bounds(self):
        self.assertTrue(GoalForm({"year": 2026, "target_hours": 100}).is_valid())
        self.assertFalse(GoalForm({"year": 2026, "target_hours": 0}).is_valid())
        self.assertFalse(GoalForm({"year": 2026, "target_hours": 10001}).is_valid())
        self.assertFalse(GoalForm({"year": 1990, "target_hours": 10}).is_valid())


class FilterTests(BaseTestCase):
    def render(self, value):
        return Template("{% load tunnit_extras %}{{ v|tunnit }}").render(Context({"v": value}))

    def test_hours_format(self):
        self.assertEqual(self.render(Decimal("2.50")), "2,5 h")
        self.assertEqual(self.render(Decimal("10.00")), "10 h")
        self.assertEqual(self.render(Decimal("0")), "0 h")
        self.assertEqual(self.render(None), "0 h")
