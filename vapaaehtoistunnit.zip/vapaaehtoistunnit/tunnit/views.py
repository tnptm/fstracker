import csv
from urllib.parse import urlencode

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, ProtectedError, Sum
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from . import services
from .forms import (
    EntryFilterForm,
    EntryForm,
    GoalForm,
    OrganizationForm,
    RegisterForm,
)
from .models import Organization, VolunteerEntry, YearlyGoal

PAGE_SIZE = 20


def _selected_year(request) -> int:
    today = timezone.localdate()
    try:
        year = int(request.GET.get("vuosi", ""))
    except ValueError:
        return today.year
    return year if 2000 <= year <= 2100 else today.year


def csv_safe(value) -> str:
    """Estää CSV-injektion: Excel tulkitsee =, +, -, @ alkavat solut kaavoiksi."""
    text = str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r", "\n") else text


# --- Rekisteröityminen -----------------------------------------------------
@require_http_methods(["GET", "POST"])
def register(request):
    if not settings.REGISTRATION_OPEN:
        raise Http404
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Tili luotu. Aloita lisäämällä ensimmäinen järjestö.")
        return redirect("organizations")
    return render(request, "registration/register.html", {"form": form})


# --- Koti ---------------------------------------------------------------------
@login_required
@require_GET
def dashboard(request):
    today = timezone.localdate()
    user = request.user
    year_hours = services.year_total(user, today.year)
    goal = YearlyGoal.objects.filter(owner=user, year=today.year).first()
    context = {
        "year": today.year,
        "year_hours": year_hours,
        "month_hours": services.month_total(user, today.year, today.month),
        "all_hours": services.sum_hours(VolunteerEntry.objects.filter(owner=user)),
        "goal": goal,
        "goal_pct": services.percent(year_hours, goal.target_hours) if goal else 0,
        "recent": VolunteerEntry.objects.filter(owner=user).select_related("organization")[:5],
        "has_orgs": Organization.objects.filter(owner=user).exists(),
    }
    return render(request, "tunnit/dashboard.html", context)


# --- Kirjaukset ---------------------------------------------------------------
@login_required
@require_http_methods(["GET", "POST"])
def entry_create(request):
    if not Organization.objects.filter(owner=request.user).exists():
        messages.info(request, "Lisää ensin vähintään yksi järjestö.")
        return redirect("organizations")
    form = EntryForm(request.POST or None, user=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Tunnit kirjattu.")
        return redirect("dashboard")
    return render(request, "tunnit/entry_form.html", {"form": form, "editing": False})


@login_required
@require_http_methods(["GET", "POST"])
def entry_edit(request, pk):
    entry = get_object_or_404(VolunteerEntry, pk=pk, owner=request.user)
    form = EntryForm(request.POST or None, instance=entry, user=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Kirjaus päivitetty.")
        return redirect("entry_list")
    return render(request, "tunnit/entry_form.html", {"form": form, "editing": True, "entry": entry})


@login_required
@require_POST
def entry_delete(request, pk):
    entry = get_object_or_404(VolunteerEntry, pk=pk, owner=request.user)
    entry.delete()
    messages.success(request, "Kirjaus poistettu.")
    return redirect("entry_list")


@login_required
@require_GET
def entry_list(request):
    filter_form = EntryFilterForm(request.GET or None, user=request.user)
    queryset = VolunteerEntry.objects.filter(owner=request.user).select_related("organization")
    params = {}
    if filter_form.is_bound and filter_form.is_valid():
        month = filter_form.cleaned_data["kuukausi"]
        org = filter_form.cleaned_data["jarjesto"]
        if month:
            queryset = queryset.filter(date__year=month.year, date__month=month.month)
            params["kuukausi"] = month.strftime("%Y-%m")
        if org:
            queryset = queryset.filter(organization=org)
            params["jarjesto"] = org.pk
    page = Paginator(queryset, PAGE_SIZE).get_page(request.GET.get("sivu"))
    context = {
        "filter_form": filter_form,
        "page": page,
        "total": services.sum_hours(queryset),
        "query": urlencode(params),
        "filtered": bool(params),
    }
    return render(request, "tunnit/entry_list.html", context)


# --- Tilastot ----------------------------------------------------------------
@login_required
@require_GET
def stats(request):
    year = _selected_year(request)
    goal = YearlyGoal.objects.filter(owner=request.user, year=year).first()
    total = services.year_total(request.user, year)
    context = {
        "year": year,
        "total": total,
        "months": services.monthly_breakdown(request.user, year),
        "orgs": services.organization_breakdown(request.user, year),
        "goal": goal,
        "goal_pct": services.percent(total, goal.target_hours) if goal else 0,
        "goal_form": GoalForm(
            initial={"year": year, "target_hours": goal.target_hours if goal else None}
        ),
    }
    return render(request, "tunnit/stats.html", context)


@login_required
@require_POST
def goal_set(request):
    form = GoalForm(request.POST)
    if form.is_valid():
        year = form.cleaned_data["year"]
        YearlyGoal.objects.update_or_create(
            owner=request.user,
            year=year,
            defaults={"target_hours": form.cleaned_data["target_hours"]},
        )
        messages.success(request, "Tavoite tallennettu.")
        return redirect(f"{reverse('stats')}?{urlencode({'vuosi': year})}")
    messages.error(request, "Tavoitteen tulee olla kokonaisluku välillä 1–10 000.")
    return redirect("stats")


@login_required
@require_GET
def export_csv(request):
    queryset = VolunteerEntry.objects.filter(owner=request.user).select_related("organization")
    filename = "vapaaehtoistunnit.csv"
    if request.GET.get("vuosi"):
        year = _selected_year(request)
        queryset = queryset.filter(date__year=year)
        filename = f"vapaaehtoistunnit-{year}.csv"
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response.write("\ufeff")  # Excel tunnistaa UTF-8:n
    writer = csv.writer(response, delimiter=";")
    writer.writerow(["Päivä", "Järjestö", "Tunnit", "Kuvaus"])
    for e in queryset.order_by("date", "id"):
        writer.writerow(
            [
                e.date.isoformat(),
                csv_safe(e.organization.name),
                str(e.hours).replace(".", ","),
                csv_safe(e.description),
            ]
        )
    return response


# --- Järjestöt -----------------------------------------------------------------
@login_required
@require_http_methods(["GET", "POST"])
def organizations(request):
    form = OrganizationForm(request.POST or None, user=request.user)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Järjestö lisätty.")
        return redirect("organizations")
    orgs = Organization.objects.filter(owner=request.user).annotate(
        total=Sum("entries__hours"), count=Count("entries")
    )
    return render(request, "tunnit/organizations.html", {"form": form, "orgs": orgs})


@login_required
@require_POST
def organization_delete(request, pk):
    org = get_object_or_404(Organization, pk=pk, owner=request.user)
    try:
        org.delete()
    except ProtectedError:
        messages.error(request, "Järjestöllä on kirjauksia. Poista tai siirrä ne ensin.")
    else:
        messages.success(request, "Järjestö poistettu.")
    return redirect("organizations")
