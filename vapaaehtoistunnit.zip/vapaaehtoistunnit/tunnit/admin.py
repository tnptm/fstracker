from django.contrib import admin

from .models import Organization, VolunteerEntry, YearlyGoal


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "created_at")
    search_fields = ("name", "owner__username")


@admin.register(VolunteerEntry)
class VolunteerEntryAdmin(admin.ModelAdmin):
    list_display = ("date", "owner", "organization", "hours")
    list_filter = ("date",)
    search_fields = ("owner__username", "organization__name", "description")


@admin.register(YearlyGoal)
class YearlyGoalAdmin(admin.ModelAdmin):
    list_display = ("owner", "year", "target_hours")
