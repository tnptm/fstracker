from django.conf import settings
from django.utils.cache import patch_cache_control

CSP = "; ".join(
    [
        "default-src 'self'",
        "script-src 'self'",
        "style-src 'self'",
        "img-src 'self' data:",
        "font-src 'self'",
        "connect-src 'self'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
    ]
)


class SecurityHeadersMiddleware:
    """Lisää CSP:n, Permissions-Policyn ja estää kirjautuneiden sivujen välimuistituksen."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        is_admin = request.path.startswith(f"/{settings.ADMIN_URL}")
        if not is_admin:  # Djangon admin käyttää inline-tyylejä
            response.headers.setdefault("Content-Security-Policy", CSP)
        response.headers.setdefault(
            "Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()"
        )
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated:
            patch_cache_control(response, private=True, no_store=True)
        return response
