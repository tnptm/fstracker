from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.utils import timezone

from .models import MAX_HOURS, MIN_HOURS, Organization, VolunteerEntry

INPUT_CLASS = (
    "block w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-base shadow-sm "
    "focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-600/30"
)


class StyledFormMixin:
    """Lisää Tailwind-luokat kaikkiin kenttiin."""

    def _apply_style(self):
        for field in self.fields.values():
            if not field.widget.is_hidden:
                field.widget.attrs.setdefault("class", INPUT_CLASS)


class EntryForm(StyledFormMixin, forms.ModelForm):
    """Tuntikirjaus. Järjestövalinta rajataan käyttäjän omiin järjestöihin (IDOR-esto)."""

    class Meta:
        model = VolunteerEntry
        fields = ["organization", "date", "hours", "description"]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "hours": forms.NumberInput(
                attrs={
                    "step": "0.25",
                    "min": str(MIN_HOURS),
                    "max": str(MAX_HOURS),
                    "inputmode": "decimal",
                    "placeholder": "esim. 2.5",
                }
            ),
            "description": forms.TextInput(
                attrs={"maxlength": 255, "placeholder": "Mitä teit? (valinnainen)"}
            ),
        }

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user
        self.instance.owner = user
        self.fields["organization"].queryset = Organization.objects.filter(owner=user)
        self.fields["organization"].empty_label = "Valitse järjestö"
        if not self.is_bound and not self.instance.pk:
            self.initial.setdefault("date", timezone.localdate())
        self._apply_style()

    def clean_date(self):
        value = self.cleaned_data["date"]
        if value > timezone.localdate():
            raise forms.ValidationError("Päivä ei voi olla tulevaisuudessa.")
        if value.year < 2000:
            raise forms.ValidationError("Anna päivä vuodelta 2000 tai myöhemmältä.")
        return value

    def clean_description(self):
        return self.cleaned_data["description"].strip()


class OrganizationForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Organization
        fields = ["name"]
        widgets = {"name": forms.TextInput(attrs={"placeholder": "Järjestön nimi", "maxlength": 100})}

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user
        self.instance.owner = user
        self._apply_style()

    def clean_name(self):
        name = " ".join(self.cleaned_data["name"].split())
        if not name:
            raise forms.ValidationError("Nimi ei voi olla tyhjä.")
        duplicate = Organization.objects.filter(owner=self.user, name__iexact=name)
        if self.instance.pk:
            duplicate = duplicate.exclude(pk=self.instance.pk)
        if duplicate.exists():
            raise forms.ValidationError("Sinulla on jo tämän niminen järjestö.")
        return name


class GoalForm(StyledFormMixin, forms.Form):
    year = forms.IntegerField(min_value=2000, max_value=2100, widget=forms.HiddenInput)
    target_hours = forms.IntegerField(
        label="Vuositavoite (tuntia)",
        min_value=1,
        max_value=10000,
        widget=forms.NumberInput(attrs={"inputmode": "numeric", "placeholder": "esim. 100"}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._apply_style()


class EntryFilterForm(StyledFormMixin, forms.Form):
    """Historian suodatus (GET). Kaikki arvot validoidaan ennen kyselyä."""

    kuukausi = forms.DateField(
        label="Kuukausi",
        required=False,
        input_formats=["%Y-%m"],
        widget=forms.DateInput(attrs={"type": "month"}, format="%Y-%m"),
    )
    jarjesto = forms.ModelChoiceField(
        label="Järjestö", queryset=Organization.objects.none(), required=False,
        empty_label="Kaikki järjestöt",
    )

    def __init__(self, *args, user, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["jarjesto"].queryset = Organization.objects.filter(owner=user)
        self._apply_style()


class RegisterForm(StyledFormMixin, UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = ("username",)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].label = "Käyttäjätunnus"
        self.fields["password1"].label = "Salasana"
        self.fields["password2"].label = "Salasana uudelleen"
        self._apply_style()
