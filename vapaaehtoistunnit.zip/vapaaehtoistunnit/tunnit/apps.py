from django.apps import AppConfig


class TunnitConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tunnit"
    verbose_name = "Vapaaehtoistunnit"
